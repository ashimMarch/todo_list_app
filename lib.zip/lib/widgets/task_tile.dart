import 'package:flutter/material.dart';
import 'package:todo_list_app/models/task.dart';

class TaskTile extends StatelessWidget {
  final Task task;
  final Function(bool?) onChanged;
  final Function() onLongPress;

  const TaskTile({
    super.key,
    required this.task,
    required this.onChanged,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(task.title),
      trailing: Checkbox(
        value: task.isCompleted,
        onChanged: onChanged,
      ),
      onLongPress: onLongPress,
    );
  }
}
