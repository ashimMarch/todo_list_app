import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/task.dart';

class TaskProvider with ChangeNotifier {
  List<Task> _tasks = [];
  final DBHelper _dbHelper = DBHelper();

  List<Task> get tasks => _tasks;

  Future<void> fetchTasks() async {
    _tasks = await _dbHelper.getTasks();
    notifyListeners();
  }

  Future<void> addTask(String title) async {
    final task = Task(id: const Uuid().v4(), title: title);
    await _dbHelper.insertTask(task);
    await fetchTasks();
  }

  Future<void> updateTask(Task task) async {
    await _dbHelper.updateTask(task);
    await fetchTasks();
  }

  Future<void> deleteTask(String id) async {
    await _dbHelper.deleteTask(id);
    await fetchTasks();
  }
}
